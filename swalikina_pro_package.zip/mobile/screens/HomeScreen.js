import React from 'react';
import { View, Text, FlatList, Image, TouchableOpacity, SafeAreaView } from 'react-native';
const sample = [
  { id: '1', title: 'Nightfall', cover: 'https://placehold.co/400x400' },
  { id: '2', title: 'Pulse', cover: 'https://placehold.co/400x400' }
];
export default function HomeScreen({ navigation }){
  return (
    <SafeAreaView style={{flex:1, backgroundColor:'#0b0b0b'}}>
      <View style={{padding:16}}>
        <Text style={{color:'#fff', fontSize:28, fontWeight:'700'}}>SWALIKINA PRO</Text>
        <Text style={{color:'#fff', marginTop:8}}>Stream. Discover. Create.</Text>
      </View>
      <FlatList
        data={sample}
        horizontal
        keyExtractor={i=>i.id}
        renderItem={({item}) => (
          <TouchableOpacity style={{margin:12}} onPress={()=>navigation.navigate('MusicDetail',{id:item.id})}>
            <Image source={{uri:item.cover}} style={{width:140,height:140,borderRadius:8}} />
            <Text style={{color:'#fff', width:140}}>{item.title}</Text>
          </TouchableOpacity>
        )}
      />
    </SafeAreaView>
  )
}
