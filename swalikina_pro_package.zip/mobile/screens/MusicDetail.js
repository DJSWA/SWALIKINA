import React, { useState, useEffect } from 'react';
import { View, Text, Image, Button } from 'react-native';
import { Audio } from 'expo-av';

export default function MusicDetail({ route }){
  const { id } = route.params;
  const [sound, setSound] = useState(null);

  async function play(){
    const { sound } = await Audio.Sound.createAsync({ uri: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3' });
    setSound(sound);
    await sound.playAsync();
  }

  useEffect(()=>{
    return sound ? () => { sound.unloadAsync(); } : undefined;
  },[sound]);

  return (
    <View style={{flex:1, backgroundColor:'#0b0b0b', padding:20}}>
      <Image source={{uri:'https://placehold.co/600x400'}} style={{width:'100%',height:220,borderRadius:8}} />
      <Text style={{color:'#fff', fontSize:22, marginTop:12}}>Sample Track</Text>
      <Button title="Play" onPress={play} />
    </View>
  )
}
