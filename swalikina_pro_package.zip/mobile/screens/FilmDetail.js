import React from 'react';
import { View, Text } from 'react-native';
export default function FilmDetail(){
  return (
    <View style={{flex:1, backgroundColor:'#0b0b0b', alignItems:'center', justifyContent:'center'}}>
      <Text style={{color:'#fff'}}>Film Detail Screen</Text>
    </View>
  )
}
