# SWALIKINA PRO — Mobile (Expo)

Run `npm install` then `expo start`.
