import { S3Client, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { verifyToken } from '../../lib/auth';

const s3 = new S3Client({ region: process.env.AWS_REGION, credentials: { accessKeyId: process.env.AWS_ACCESS_KEY_ID, secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY } });

export default async function handler(req, res){
  const token = req.headers.authorization?.split(' ')[1] || null;
  const user = await verifyToken(token);
  if (!user) return res.status(401).json({ error: 'Unauthorized' });
  const { key } = req.query;
  if (!key) return res.status(400).json({ error: 'Missing key' });
  try{
    const cmd = new GetObjectCommand({ Bucket: process.env.AWS_S3_BUCKET, Key: key });
    const url = await getSignedUrl(s3, cmd, { expiresIn: 900 });
    return res.status(200).json({ url });
  } catch(err){
    console.error(err);
    return res.status(500).json({ error: 'Could not generate download URL' });
  }
}
