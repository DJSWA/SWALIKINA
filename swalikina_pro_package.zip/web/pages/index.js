import Head from 'next/head'
import SwalikinaProStarter from '../components/SwalikinaProStarter'

export default function Home(){
  return (
    <>
      <Head>
        <title>SWALIKINA PRO — Music and Filmz</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </Head>
      <SwalikinaProStarter />
    </>
  )
}
