# SWALIKINA PRO — Web

This is the Next.js starter. Install deps and run `npm run dev`.
